/*
  NAME: Kacper Gęśla
  ID: 290168
*/
public class JAVA_01_01 {

    public static void main(String[] args) {

        System.out.println("Hello World!");
    }
}